package model;

/** Clase "Score" del modelo.
 * @author Gonz�lez Fernandez Cristian y Vel�zquez Vico �lvaro
 * @version 1 - Last changes: -
 */
public class Square {
	
	private int id;
	private String category;
	private Question question;
	
	
	public Square(int id, String category){
		this.id = id;
		this.category = category;
	}
		
	public int getId() {
		return id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public Question getQuestion(){
		return question;
	}
	
}
