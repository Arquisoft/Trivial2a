package test;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static play.test.Helpers.HTMLUNIT;
import static play.test.Helpers.contentAsString;
import static play.test.Helpers.contentType;
import static play.test.Helpers.fakeApplication;
import static play.test.Helpers.inMemoryDatabase;
import static play.test.Helpers.running;
import static play.test.Helpers.testServer;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import play.data.Form;
import play.libs.F.Callback;
import play.test.TestBrowser;
import play.twirl.api.Content;
import bussines.GameAPI;
import bussines.exceptions.IllegalActionException;
import bussines.fileLoaders.BoardOptionsLoader;
import bussines.gameClasses.BoardOptionsFactory;
import controllers.Application.Login;
import factories.BusinessFactory;


/**
*
* Simple (JUnit) tests that can call all parts of a play app.
* If you are interested in mocking a whole application, see the wiki for more details.
*
*/
public class ApplicationTest {

    @Test
    public void simpleCheck() {
        int a = 1 + 1;
        assertThat(a).isEqualTo(2);
    }

    @Test
    public void renderTemplate() {
    	Content html = views.html.login.render(Form.form(Login.class));
        assertThat(contentType(html)).isEqualTo("text/html");
        assertThat(contentAsString(html)).contains("Iniciar sesión");
    }
    
    @Test
    public void testApi(){
    	GameAPI api = BusinessFactory.getGameAPI();
		List<String> players = new ArrayList<String>();
		players.add("Ruan");
		try {
			api.startGame(players, BoardOptionsFactory.getBoardOption(0));
		} catch (IllegalActionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
   

}
