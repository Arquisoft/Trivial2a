package persistence.impl;

import model.Score;
import model.User;
import persistence.ScoreDao;

public class ScoreJdbcDao implements ScoreDao {

	@Override
	public Score getMaxScore() {
		return null;
	}

	@Override
	public User getUserMaxScore() {
		return null;
	}

}
