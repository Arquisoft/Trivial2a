package bussines.gameClasses;

import java.util.List;

import bussines.fileLoaders.BoardOptionsLoader;

/**
 * Class that grant access and stores the different BoardOption items.
 * 
 * @author Montero Hernández, José Antonio
 *
 */
public class BoardOptionsFactory {

	public static final String BOARDS_FOLDER = "resources/boards/";
	public static final String BOARDOPTIONS_FILE = "boardOptions.txt";

	private static List<BoardOption> boardOptions = new BoardOptionsLoader()
			.loadBoardOptions(BOARDS_FOLDER + BOARDOPTIONS_FILE);

	public static List<BoardOption> getBoardOptions() {
		return boardOptions;
	}
	
	public static BoardOption getBoardOption(int boardOptionId) {
		return boardOptions.get(boardOptionId);
	}
}
