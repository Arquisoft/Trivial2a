package model;

/** Clase "Statistic" del modelo.
 * @author Gonz�lez Fernandez Cristian y Vel�zquez Vico �lvaro
 * @version 1 - Last changes: -
 */
public class Statistic {
	
	//Correct answers
	private int sports;
	private int showsAndEntertainment;
	private int scienceAndTechnology;
	private int artAndLiterature;
	private int geography;
	private int history;
	
	private int Totalsports;
	private int TotalshowsAndEntertainment;
	private int TotalscienceAndTechnology;
	private int TotalartAndLiterature;
	private int Totalgeography;
	private int Totalhistory;
	
	//Getters and setters
	public int getSports() {
		return sports;
	}
	public void setSports(int sports) {
		this.sports = sports;
	}
	public int getShowsAndEntertainment() {
		return showsAndEntertainment;
	}
	public void setShowsAndEntertainment(int showsAndEntertainment) {
		this.showsAndEntertainment = showsAndEntertainment;
	}
	public int getScienceAndTechnology() {
		return scienceAndTechnology;
	}
	public void setScienceAndTechnology(int scienceAndTechnology) {
		this.scienceAndTechnology = scienceAndTechnology;
	}
	public int getArtAndLiterature() {
		return artAndLiterature;
	}
	public void setArtAndLiterature(int artAndLiterature) {
		this.artAndLiterature = artAndLiterature;
	}
	public int getGeography() {
		return geography;
	}
	public void setGeography(int geography) {
		this.geography = geography;
	}
	public int getHistory() {
		return history;
	}
	public void setHistory(int history) {
		this.history = history;
	}
	public int getTotalsports() {
		return Totalsports;
	}
	public void setTotalsports(int totalsports) {
		Totalsports = totalsports;
	}
	public int getTotalshowsAndEntertainment() {
		return TotalshowsAndEntertainment;
	}
	public void setTotalshowsAndEntertainment(int totalshowsAndEntertainment) {
		TotalshowsAndEntertainment = totalshowsAndEntertainment;
	}
	public int getTotalscienceAndTechnology() {
		return TotalscienceAndTechnology;
	}
	public void setTotalscienceAndTechnology(int totalscienceAndTechnology) {
		TotalscienceAndTechnology = totalscienceAndTechnology;
	}
	public int getTotalartAndLiterature() {
		return TotalartAndLiterature;
	}
	public void setTotalartAndLiterature(int totalartAndLiterature) {
		TotalartAndLiterature = totalartAndLiterature;
	}
	public int getTotalgeography() {
		return Totalgeography;
	}
	public void setTotalgeography(int totalgeography) {
		Totalgeography = totalgeography;
	}
	public int getTotalhistory() {
		return Totalhistory;
	}
	public void setTotalhistory(int totalhistory) {
		Totalhistory = totalhistory;
	}		

}
