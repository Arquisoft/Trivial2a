package model;

public enum SquareType {
	FINAL, DICE, GAME_PIECE, NORMAL

}